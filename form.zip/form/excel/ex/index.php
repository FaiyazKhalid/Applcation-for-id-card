<?php
// The function header by sending raw excel
header("Content-type: application/vnd-ms-excel");
 // Defines the name of the export file "codelution-export.xls"
header("Content-Disposition: attachment; filename=system_users.xls");
 // Add data table

?>

<table width=30% height=30% border="1" align="center">
<tr><th>Photo</th></tr>
<tr><td><img width="120" height="110"  SRC="https://gnim.in/data1/form/excel/ex/images/cmd.png" alt="Image failed to load " /></td></tr>
</table>

<?
$original = imagecreatefromjpeg("images/cmd.png");
$resized = imagecreatetruecolor(NEW WIDTH, NEW HEIGHT);
imagecopyresampled($resized, $original, 0, 0, 0, 0, NEW WIDTH, NEW HEIGHT, WIDTH, HEIGHT);
imagejpeg($resized, "RESIZED.jpg");
?>