<?php
session_start();

if(isset($_POST['submit_pass']) && $_POST['pass'])
{
 $pass=$_POST['pass'];
 if($pass=="azadd3395")
 {
  $_SESSION['password']=$pass;
 }
 else
 {
  $error="Incorrect Pssword";
 }
}

if(isset($_POST['page_logout']))
{
 unset($_SESSION['password']);
}
?>

<div id="wrapper">

<?php
if($_SESSION['password']=="imtiyazkhalid3395")
{
 ?>
<!DOCTYPE html>
<html>
 <head>
 <title>Participants</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<?php
include_once 'dbconnect.php';

$limit = 10;  
if (isset($_GET["page"])) {
	$page  = $_GET["page"]; 
	} 
	else{ 
	$page=1;
	};  
$start_from = ($page-1) * $limit;  

$result = mysqli_query($conn,"SELECT * FROM forms ORDER BY id DESC LIMIT $start_from, $limit");

?>

 </head>
<body>
  <table class="table table-bordered table-striped">
  
  <tr>
      <td>Photo</td>
    <td>First Name</td>
    <td>Last Name</td>
    <td>Email id</td>
    <td>Phone</td>
    <td>Country</td>
    <td>State</td>
    <td>City</td>
    <td>About</td>
    <td>File</td>
    <td>Link</td>
    <td>Date</td>
    
  </tr>
<?php  
while ($row = mysqli_fetch_array($result)) {  
?> 
<tr>
    <td><img src="https://redmusicseries.com/images/<?php echo $row["photo"]; ?>" alt="Girl in a jacket" width="30" height="50"></td>
    <td><?php echo $row["fname"]; ?></td>
    <td><?php echo $row["lname"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
    <td><?php echo $row["phone"]; ?></td>
    <td><?php echo $row["country"]; ?></td>
    <td><?php echo $row["state"]; ?></td>
    <td><?php echo $row["city"]; ?></td>
    <td><?php echo $row["expression"]; ?></td>
    <td><a href="https://redmusicseries.com/file/<?php echo $row["file"]; ?>">Download</a></td>
    <td><a href="<?php echo $row["url"]; ?>"><?php echo $row["url"]; ?></a></td>
    <td><?php echo $row["date"]; ?></td>

</tr>
<?php  
};  
?>
</table>
<?php  

$result_db = mysqli_query($conn,"SELECT COUNT(id) FROM forms"); 
$row_db = mysqli_fetch_row($result_db);  
$total_records = $row_db[0];  
$total_pages = ceil($total_records / $limit); 
/* echo  $total_pages; */
$pagLink = "<ul class='pagination'>";  
for ($i=1; $i<=$total_pages; $i++) {
              $pagLink .= "<li class='page-item'><a class='page-link' href='admin.php?page=".$i."'>".$i."</a></li>";	
}
echo $pagLink . "</ul>";  
?>
 </body>
 <style>
     table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;

}

tr:nth-child(even) {
    background-color: white;
}


 </style>
 <form method="post" action="" id="logout_form">
  <input type="submit" name="page_logout" value="LOGOUT">
 </form>
 <?php
}
else
{
 ?>
 <form method="post" action="" id="login_form">
  <h1>LOGIN TO PROCEED</h1>
  <input type="password" name="pass" placeholder="*******">
  <input type="submit" name="submit_pass" value="DO SUBMIT">
  <p>"Password Protected."</p>
  <p><font style="color:red;"><?php echo $error;?></font></p>
 </form>
 <?php	
}
?>

</div>
<style>
    body
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:100%;
 font-family: "Myriad Pro","Helvetica Neue",Helvetica,Arial,Sans-Serif;
 background-color:#d3d3d3;
}
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:white;
}
#wrapper p
{
 font-size:16px;
}
#logout_form input[type="submit"]
{
 width:250px;
 margin-top:10px;
 height:40px;
 font-size:16px;
 background:none;
 border:2px solid white;
 color:white;
}
#login_form
{
 margin-top:200px;
 background-color:white;
 width:350px;
 margin-left:310px;
 padding:20px;
 box-sizing:border-box;
 box-shadow:0px 0px 10px 0px #3B240B;
}
#login_form h1
{
 margin:0px;
 font-size:25px;
 color:#8A4B08;
}
#login_form input[type="password"]
{
 width:250px;
 margin-top:10px;
 height:40px;
 padding-left:10px;
 font-size:16px;
}
#login_form input[type="submit"]
{
 width:250px;
 margin-top:10px;
 height:40px;
 font-size:16px;
 background-color:#8A4B08;
 border:none;
 box-shadow:0px 4px 0px 0px #61380B;
 color:white;
 border-radius:3px;
}
#login_form p
{
 margin:0px;
 margin-top:15px;
 color:#8A4B08;
 font-size:17px;
 font-weight:bold;
}
</style>
</html>