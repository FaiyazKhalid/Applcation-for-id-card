
<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"/>
    <link rel="stylesheet" href="assets/css/style.css" type="text/css"/>
<style>
    select.form-control {
    -moz-appearance: none;
    -webkit-appearance: none;
    appearance: none;
    background-position: right center;
    background-repeat: no-repeat;
    background-size: 1ex;
    background-origin: content-box;
    
}
body {
background-color: paleturquoise;
}
</style>
<script src="geo/assets/js/jquery.min.js"></script>
<script src="geo/assets/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

    <div id="login-form">
        <form method="post" action="action.php"  enctype="multipart/form-data" autocomplete="off">

            <div class="col-md-12">

                <div class="form-group">
                    <h3 class="">STUDENT COLLEGE ID CARD</h3>
                </div>

                <div class="form-group">
                    <hr/>
                </div>

                <?php
                if (isset($errMSG)) {

                    ?>
                    <div class="form-group">
                        <div class="alert alert-<?php echo ($errTyp == "success") ? "success" : $errTyp; ?>">
                            <span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                        </div>
                    </div>
                    <?php
                }
                ?>


<div class="form-group">
<p>1. Select your course Session:</p>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-star"></span></span>
<select class="form-control" name="session">
  <option value="">Select...</option>
  <option value="2019">2019</option>
    <option value="2020">2020</option>
        <option value="2021">2021</option>
</select>
</div>
</div>

<div class="form-group">
<p>2. Select your course:</p>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-book"></span></span>
<select class="form-control" name="course">
<option value="">Select...</option>
<option value="B.TECH COMPUTER SCIENCE">B.TECH COMPUTER SCIENCE</option>
<option value="B.TECH COMPUTER SCIENCE (AI)">B.TECH COMPUTER SCIENCE (AI)</option>
  <option value="DIPLOMA COMPUTER SCIENCE">DIPLOMA COMPUTER SCIENCE</option>
  <option value="DIPLOMA ELECTRICAL">DIPLOMA ELECTRICAL</option>
  <option value="DIPLOMA MECHANICA">DIPLOMA MECHANICAL</option>
  <option value="B.TECH IP COMPUTER SCIENCE">B.TECH IP COMPUTER SCIENCE</option>
  <option value="F">B.TECH IP MACHENICAL ENGINEERING</option>
  <option value="B.TECH IP MACHENICAL ENGINEERING">B.TECH IP ELECTRONICS & COMMUNICATION ENGINEERING</option>
  <option value="B.TECH IP INFORMATION TECHINOLOGY">B.TECH IP INFORMATION TECHINOLOGY</option>
  <option value="D.PHARMA">D.PHARMA</option>
  <option value="F">B.PHARMA</option>
  <option value="B.PHARMA">MBA</option>
  <option value="BBA">BBA</option>
  <option value="BCA">BCA</option>
  <option value="B.COM">B.COM</option>
  <option value="B.PHARMA">B.PHARMA</option>
    <option value="LLB">LLB</option>
  <option value="BA.LLB">BA.LLB</option>
  <option value="B.COM.LLB">B.COM.LLB</option>
</select>
</div>
</div>
                
                <div class="form-group">
                    <p>3. Upload your photo</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-picture"></span></span>
                        <input type="file" name="photo" class="form-control" placeholder="Upload"
                               required/>
                    </div>
                </div>
                
                  <div class="form-group">
                <p>4. Student's ID Number</p>
             
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-number"></span></span>
                        <input type="text" name="sid" class="form-control" placeholder="Enter Student ID" required/>
                    </div>
                </div>

                <div class="form-group">
                <p>5. Student's Name</p>
                <small>Write your Full Name</small>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                        <input type="text" name="name" class="form-control" placeholder="Enter Student Name" required/>
                    </div>
                </div>
                
               <div class="form-group">
                                       <p>6. Father's Name</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                        <input type="text" name="father" class="form-control" placeholder="Enter Father Name" required/>
                    </div>
                </div>



                <div class="form-group">
                                        <p>7. Email</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
                        <input type="email" name="email" class="form-control" placeholder="Enter Email" required/>
                    </div>
                </div>

                <div class="form-group">
                     <p>8.Permanent Contact Number</p>
                    <div class="input-group">
                                           
                        <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                        <input type="number" name="phone" class="form-control" placeholder="Enter Phone Number" required/>
                    </div>
                </div>

                <div class="form-group">
                     <p>9.Whatsapp Number</p>
                    <div class="input-group">
                                           
                        <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                        <input type="number" name="whatsapp" class="form-control" placeholder="Enter Whatsapp Number" required/>
                    </div>
                </div>
                <div class="form-group">
                                        <p>10. Write your Full Address...</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-pen"></span></span>
                        <textarea type="text" name="address" class="form-control" placeholder="Type Full Address" required/></textarea>
                    </div>
                </div>

                <div class="checkbox">
                    <label><input type="checkbox" id="TOS" value="This"><a href="#">I have cross checked the information.</a></label>
                </div>

  <div class="form-group">
                    <p>11. Terms and Conditions</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-file"></span></span>
                        <textarea type="text" name="nothing" readonly class="form-control" placeholder="Upload"
                               required/>Filling incorrect or misleading information will be laible to be fine.
                               </textarea>
                    </div>
                </div>


                <div class="form-group">
                    <button type="submit" class="btn    btn-block btn-primary" name="signup" id="reg">Register</button>
                </div>

            
                
            </div>

        </form>
    </div>

</div>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

</body>


</html>
