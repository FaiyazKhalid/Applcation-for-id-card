<?php

include 'Studentid/db_connect.php';

?>
<?php

    if(isset($_POST['signup']))
    {

 $file1 = rand(1000,100000)."-".$_FILES['photo']['name'];
    $file_loc1 = $_FILES['photo']['tmp_name'];
    $folder1="Studentid/images/";
    $new_file_name1 = strtolower($file1);
    $photo=str_replace(' ','-',$new_file_name1);
 
move_uploaded_file($file_loc1,$folder1.$photo);

        $session = $_POST['session'];
        $course = $_POST['course'];
        $sid = $_POST['sid'];
        $name = $_POST['name'];
        $father = $_POST['father'];
        $phone = $_POST['phone'];
        $whatsapp = $_POST['whatsapp'];
        $address = $_POST['address'];
                $email = $_POST['email'];



        $query = "insert into student_id_card (session,course,sid,name,father,email,photo,phone,whatsapp,address) values ('$session','$course','$sid','$name','$father','$email','$photo','$phone','$whatsapp','$address')";

        $result = mysqli_query($db, $query);

        if($result==1)
        {       

        echo "<center><h2>Submitted successfully</h2></center>";
        
        }
        else {       

        echo "Insertion Failed";

             }
    }
?>