
<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"/>
    <link rel="stylesheet" href="assets/css/style.css" type="text/css"/>
<style>
    select.form-control {
    -moz-appearance: none;
    -webkit-appearance: none;
    appearance: none;
    background-position: right center;
    background-repeat: no-repeat;
    background-size: 1ex;
    background-origin: content-box;
    
}
body {
background-color: paleturquoise;
}
</style>
<script src="geo/assets/js/jquery.min.js"></script>
<script src="geo/assets/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

    <div id="login-form">
        <form method="post" action="action-faculty.php"  enctype="multipart/form-data" autocomplete="off">

            <div class="col-md-12">

                <div class="form-group">
                    <h3 class="">FACULTY COLLEGE ID CARD</h3>
                </div>

                <div class="form-group">
                    <hr/>
                </div>

                <?php
                if (isset($errMSG)) {

                    ?>
                    <div class="form-group">
                        <div class="alert alert-<?php echo ($errTyp == "success") ? "success" : $errTyp; ?>">
                            <span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                        </div>
                    </div>
                    <?php
                }
                ?>




<div class="form-group">
<p>1. Select your Institute:</p>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-book"></span></span>
<select class="form-control" name="institute">
<option value="">Select...</option>
<option value="GREATER NOIDA INSTITUTE OF TECHNOLOGY (IPC CAMPUS)">GREATER NOIDA INSTITUTE OF TECHNOLOGY (IPC CAMPUS)</option>
<option value="GREATER NOIDA INSTITUTE OF MANAGEMENT">GREATER NOIDA INSTITUTE OF MANAGEMENT</option>
 <option value="GNIT COLLEGE OF MANAGEMENT">GNIT COLLEGE OF MANAGEMENT</option>
  <option value="GREATER NOIDA INSTITUTE OF LAW">GREATER NOIDA INSTITUTE OF LAW</option>
  <option value="GREATER NOIDA INSTITUTE OF PHARMACY">GREATER NOIDA INSTITUTE OF PHARMACY</option>
  <option value="GREATER NOIDA COLLEGE">GREATER NOIDA COLLEGE</option>
  
</select>
</div>
</div>
                
                <div class="form-group">
                    <p>2. Upload your photo</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-picture"></span></span>
                        <input type="file" name="photo" class="form-control" placeholder="Upload"
                               required/>
                    </div>
                </div>
                
                  

                <div class="form-group">
                <p>3. Faculty's Name</p>
                <small>Write your Full Name</small>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                        <input type="text" name="name" class="form-control" placeholder="Enter Student Name" required/>
                    </div>
                </div>
                <div class="form-group">
                                       <p>4. Father's Name</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                        <input type="text" name="father" class="form-control" placeholder="Enter Father Name" required/>
                    </div>
                </div>
                
               <div class="form-group">
                                       <p>4. Designation</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                        <input type="text" name="designation" class="form-control" placeholder="Enter Designation" required/>
                    </div>
                </div>



                <div class="form-group">
                                        <p>5. Email</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
                        <input type="email" name="email" class="form-control" placeholder="Enter Email" required/>
                    </div>
                </div>

                <div class="form-group">
                     <p>6.Permanent Contact Number</p>
                    <div class="input-group">
                                           
                        <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                        <input type="number" name="phone" class="form-control" placeholder="Enter Phone Number" required/>
                    </div>
                </div>

                <div class="form-group">
                     <p>7.Whatsapp Number</p>
                    <div class="input-group">
                                           
                        <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                        <input type="number" name="whatsapp" class="form-control" placeholder="Enter Whatsapp Number" required/>
                    </div>
                </div>
                <div class="form-group">
                                        <p>8. Write your Full Address...</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-pen"></span></span>
                        <textarea type="text" name="address" class="form-control" placeholder="Type Full Address" required/></textarea>
                    </div>
                </div>

                <div class="checkbox">
                    <label><input type="checkbox" id="TOS" value="This"><a href="#">I have cross checked the information.</a></label>
                </div>



                <div class="form-group">
                    <button type="submit" class="btn    btn-block btn-primary" name="signup" id="reg">Register</button>
                </div>

            
                
            </div>

        </form>
    </div>

</div>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

</body>


</html>
