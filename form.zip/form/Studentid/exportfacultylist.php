<?php
// The function header by sending raw excel
header("Content-type: application/vnd-ms-excel");
 // Defines the name of the export file "codelution-export.xls"
header("Content-Disposition: attachment; filename=system_users.xls");
 // Add data table

?>
<table>
        <thead>
                                                <tr>
                                                    <th data-field="state" data-checkbox="true"></th>
            	<th>ID</th>
            	<th style='width:220px !important;background-color:#c7c7c7;'>PHOTO</th>
              
                <th>INSTITUTE</th>
                <th>NAME</th>              
                <th>FATHER</th>
                <th>PHONE</th>           
                <th>WHATSAPP</th>
                <th>ADDRESS</th>
                <th>EMAIL</th>
                <th>Print</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
        	 <?php   
        	 include("db_connect.php");
        	 $sqlmember ="SELECT * FROM faculty_id_card ";
			       $retrieve = mysqli_query($db,$sqlmember);
				                    $count=0;
                     while($found = mysqli_fetch_array($retrieve))
	                 {
                   
                       $institute=$found['institute'];
                       $name=$found['name'];
                       $father=$found['father'];
                       $phone=$found['phone'];
                       $whatsapp=$found['whatsapp'];
			                $count=$count+1;  
			                $address=$found['address']; 
			                $photo=$found['photo'];
			                			                $email=$found['email'];
					    	 
			      echo"<tr>    
			                 <td>$count</td>  
			                 <td>$id</td> 
			                 

			                 
			                 
			                 
			                          <td style='text-align:center;width:60px !important;height:150px !important;'><img width='70' height='70'  SRC='https://gnim.in/data1/form/Studentid/images/$photo'> </td>
       
			                 <td>$institute</td>
                                   	
                             <td>$name</td>
                             <td>$father</td>
                             <td>$phone</td>
			                 <td>$whatsapp</td>
			                 <td>$address</td>
			                 <td>$email</td>
			                 <td>
			                   <a  href='card.php?id=$id' class='btn  btn-success' title='click to print report' ><span class='glyphicon glyphicon-print' style='color:white;'></span></a>
                              </td>
			                 <td>
			                   <a data-toggle='modal' data-id='$id' data-ie='$firstname'   data-if='$sirname' data-ig='$rank' data-ih='$dept' data-ij='$contact' data-ik='$pass' class='open-Passwords btn  btn-info' title='edit user details' href='#Passwords'><span class='glyphicon glyphicon-edit' style='color:white;'></span></a>
							 
			                 </td>				                 
			                 <td>
			                   <a data-id='$id'  class='open-Delete btn  btn-danger' title='delete user' ><span class='glyphicon glyphicon-trash' style='color:white;'></span></a>
							 
			                 </td>			 
                             </tr>"; 
					 
					 } 
		
		           	?>
            </tbody>
        
    </table>
             