<p> <?php if(isset($code)){ echo$code;}?>
      			</p>
      		 <?php if(isset($name)){ echo"Property of ".$name;}?>