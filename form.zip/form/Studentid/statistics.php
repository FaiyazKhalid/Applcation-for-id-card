<?php 
session_start();
include("db_connect.php");

if(isset($_COOKIE['adminid'])&&$_COOKIE['adminemail']){
	
	$userid=$_COOKIE['adminid'];
$useremail=$_COOKIE['adminemail'];

$sqluser ="SELECT * FROM Administrator WHERE Password='$userid' && Email='$useremail'";

$retrieved = mysqli_query($db,$sqluser);
    while($found = mysqli_fetch_array($retrieved))
	     {
              $firstname = $found['Firstname'];
		      $sirname= $found['Sirname'];
			  $emails = $found['Email'];
			  	   $id= $found['id'];			  
   
  	     
}		 
		 
}else{
	 header('location:index.php');
      exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>

<h1>Student Statistics</h1>

<table id="customers">
  <tr><?php 
$sql ="SELECT * from student_id_card";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
    <th>S.No.</th>
    <th>Course</th>
 <th>Total</th>
   
</tr>
  <tr>
    <td>1</td>
    <td>All Course</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>

</tr>
  <tr>
     <?php 
$sql ="SELECT * from student_id_card where course='B.TECH COMPUTER SCIENCE' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
                                        
                                          
    <td>2</td>
    <td>B.TECH COMPUTER SCIENCE</td>
    <td><span class="counter"><?php echo htmlentities($totalverapp);?></span></td>
  </tr>
  <tr>
   <?php 
$sql ="SELECT * from student_id_card where course='B.TECH COMPUTER SCIENCE (AI)' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
                                        
                                            
    <td>3</td>
    <td><p>B.TECH COMPUTER SCIENCE (AI)</p></td>
    <td><span class="counter"><?php echo htmlentities($totalrejapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='DIPLOMA COMPUTER SCIENCE'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
    <td>4</td>
    <td>DIPLOMA COMPUTER SCIENCE</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='DIPLOMA ELECTRICAL' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>5</td>
    <td>DIPLOMA ELECTRICAL</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
    <?php 
$sql ="SELECT * from student_id_card where course='DIPLOMA MECHANICAL' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
    <td>6</td>
    <td>DIPLOMA MECHANICAL</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
   <?php 
$sql ="SELECT * from student_id_card where course='B.TECH IP COMPUTER SCIENCE'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
    <td>7</td>
    <td>B.TECH IP COMPUTER SCIENCE</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='B.TECH IP MACHENICAL ENGINEERING' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>8</td>
    <td>B.TECH IP MACHENICAL ENGINEERING</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
   <?php 
$sql ="SELECT * from student_id_card where course='B.TECH IP MACHENICAL ENGINEERING & COMMUNICATION ENGINEERING' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
    <td>9</td>
    <td>B.TECH IP ELECTRONICS & COMMUNICATION ENGINEERING</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
   <?php 
$sql ="SELECT * from student_id_card where course='B.TECH IP INFORMATION TECHINOLOGY'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
    <td>10</td>
    <td>B.TECH IP INFORMATION TECHINOLOGY</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='D.PHARMA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>11</td>
    <td>D.PHARMA</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='B.PHARMA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>12</td>
    <td>B.PHARMA</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='MBA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>13</td>
    <td>MBA</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='BBA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>14</td>
    <td>BBA</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='BCA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>15</td>
    <td>BCA</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='B.COM' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>16</td>
    <td>B.COM</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='LLB' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>17</td>
    <td>LLB</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
   <tr>
   <?php 
$sql ="SELECT * from student_id_card where course='BA.LLB' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>18</td>
    <td>BA.LLB</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
  <tr>
  <?php 
$sql ="SELECT * from student_id_card where course='B.COM.LLB' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
    <td>19</td>
    <td>B.COM.LLB</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>
  </tr>
</table>

</body>
</html>


