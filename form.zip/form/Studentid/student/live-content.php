<?php
$url='localhost';
$username='advocate_mw8';
$password='V.Qf6FQ7nQdh6EeVeb272';
$conn=mysqli_connect($url,$username,$password,"advocate_mw8");
if(!$conn){
 die('Could not Connect My Sql:' .mysql_error());
}
?>

<?php
$result = mysqli_query($conn,"SELECT rc_title FROM `mw_recentchanges` ORDER BY `rc_id` DESC limit 10 ");
?>

<?php
if (mysqli_num_rows($result) > 0) {
?>
  
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<table>
<ul>    
<?php echo $row["rc_title"]; ?>
</ul>
</table>
<?php


$i++;
}
?>


 <?php
}
else{
    echo "No result found";
}
?>

 