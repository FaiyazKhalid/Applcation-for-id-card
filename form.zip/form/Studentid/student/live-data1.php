<?php
$url='localhost';
$username='advocate_mw8';
$password='V.Qf6FQ7nQdh6EeVeb272';
$conn=mysqli_connect($url,$username,$password,"advocate_mw8");
if(!$conn){
 die('Could not Connect My Sql:' .mysql_error());
}
?>

<?php
$result = mysqli_query($conn,"SELECT * FROM `mw_missed_pages` ORDER BY `mp_id` DESC limit 10");
?>

<?php
if (mysqli_num_rows($result) > 0) {
?>
  
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<table ><td><?php echo $row["mp_page_title"]; ?></td></table>
<?php


$i++;
}
?>
<audio id="audioplayer" preload>
    <source src="notify.mp3">
</audio>
 <?php
}
else{
    echo "No result found";
}
?>